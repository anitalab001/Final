import pandas as pd
import numpy as np
import dataframe_image as dfi
from datetime import datetime,timedelta
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import zhplot
import logging
import os
from pathlib import Path
import json

import warnings
warnings.simplefilter(action='ignore')

## Path
BASE_DIR = Path(r"C:\Users\A51857\Desktop\study\交接項目\策略損益圖程式")
STRATEGIES_DIR = BASE_DIR/"strategy"
LOG_DIR = BASE_DIR / "log"
RETURN_PICTURE_DIR = BASE_DIR / "return picture"
STRATEGIES_FILE = BASE_DIR / "Strategy_bank.json"

## Strategy bank
'''
Strategy bank: list the Strategy need to be update.
format: (MarketName)_(TradeType)_Strategies : {"(StrategyName)":true/fasle,...}
MarketName : the shortname of the market. ex: txf,nq...
TradeType : DayTrade or Swing
StrategyName: the name of the strategy. ex: TXF0001
if true then the code will records and update the strategy, else will not.
** Since the data is record in excel and there is some limit in excel funtion, Strategy name is suitable named by alphabet and numeric only, must not contain "-,!~".
'''
with open(STRATEGIES_FILE, 'r') as f:
    strategies = json.load(f)

for key, value in strategies.items():
    globals()[key] = value 
## Market
goods = {key.upper(): globals()[key] for key in strategies.keys()}

## four Dimention tables
df_x = pd.DataFrame()
df_x['X'] = [0,0.1,0.2,0.3,0.4,0.6,0.65,0.75,0.85,0.9]
df_x['Gap'] = [0.1,0.2,0.3,0.4,0.6,0.65,0.75,0.85,0.9,1]
df_x[6] = [1,2,3,4,5,6,7,8,9,10]
df_y = pd.DataFrame()
df_y['Y'] = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]
df_y['Gap'] = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
df_y[7] = [1,2,3,4,5,6,7,8,9,10]

## Funtions
def read_history_profit(sheet_name):
    """
    Reads the history profit from an Excel file.
    sheet_name : str, sheet name.
    """
    try:
        return pd.read_excel(
            BASE_DIR / "Historical Strategy Model Profit.xlsx",
            sheet_name=sheet_name,
            header=None,
            index_col=False
        )
    except FileNotFoundError:
        logging.warning(f" Sheet : {sheet_name} didn't exist. Creating a new sheet.")
        return pd.DataFrame(columns=[0, 1])

def read_lastest_profit(strategy_name):
    try:
        with open(STRATEGIES_DIR / f"{strategy_name}.txt", 'r') as f:
            lastday_profit_str,today_profit_str = f.readlines()[-2:]
            lastday_profit_list = lastday_profit_str.split(' ')
            lastday_profit = float(''.join([c for c in lastday_profit_list[-1] if c in '1234567890.-']))
            today_profit_list = today_profit_str.split(' ')
            today_profit = float(''.join([c for c in today_profit_list[-1] if c in '1234567890.-']))
            lastdate = pd.to_datetime(lastday_profit_list[0])
            date = pd.to_datetime(today_profit_list[0])
            logging.debug(f"lastest profit of {strategy_name}: Date: {lastdate} = {lastday_profit}, Date: {date} = {today_profit}")
            return today_profit, date ,lastday_profit, lastdate
    except FileNotFoundError:
        print(f"{strategy_name} didn't record.")
        logging.warning(f"File for strategy {strategy_name} lastest daily profit not found. Using default values.")
        lastday_profit = np.nan
        today_profit = np.nan
        lastdate = datetime.today() - timedelta(days=2)
        date = datetime.today() - timedelta(days=1)
        return today_profit, date ,lastday_profit, lastdate

def update_history_profit(history_data, today_profit, date, lastday_profit, lastdate, index_col):
    """
    Add lastest data to history.
    """
    history_data = history_data.set_index(index_col)
    if lastday_profit!=0:
        history_data.loc[lastdate.replace(hour=0, minute=0, second=0, microsecond=0), 1] = lastday_profit
    if today_profit!=0:
        history_data.loc[date.replace(hour=0, minute=0, second=0, microsecond=0), 1] = today_profit
    return history_data

def count_mdd(profits,window):
    Max_profit = profits.rolling(window,min_periods=1).max()
    mdd = profits-Max_profit
    mdd_pct = (profits/Max_profit-1)*100
    return mdd,mdd_pct

def count_backtest(df_profit,df_result,strategy_name,market_name,activate_date,type='DayTrade'):
    df_profit = df_profit.fillna(0)
    df = df_profit[df_profit[1]!=0]
    df= df.replace(to_replace=0, method='ffill')
    df['Cum'] = df[1].cumsum()
    df['Return'] = df['Cum'].pct_change()
    df_month = pd.DataFrame(df.groupby(pd.Grouper(freq='ME'))[1].sum())
    df_month['Times'] = pd.DataFrame(df.groupby(pd.Grouper(freq='ME'))[1].count())
    df_month['Cum'] = df_month[1].cumsum()
    df_month['Return'] = df_month['Cum'].pct_change()
    df_win = df[df[1]>0]
    df_loss = df[df[1]<0]
    win_rate = (len(df_win)/len(df))*100
    month_times = (df_month['Times']/25).mean()*100
    win_factor = abs(df_win[1].sum()/df_loss[1].sum())
    adjust_win_factor = df_win[df_win[1]<df_win[1].mean()+df_win[1].std()*3][1].sum()/max(1,abs(df_loss[df_loss[1]>df_loss[1].mean()-abs(df_loss[1].std())*3][1].sum()))
    sharp_ratio = ((df_month['Return'].mean()-0.0025)/df_month['Return'].std())
    
    sharp_ratio_year= sharp_ratio*(12**(1/2))

    df_result.loc['日勝率',str(strategy_name)] = f'{win_rate:.2f} %'
    df_result.loc['月平均交易頻率',str(strategy_name)] = f'{month_times:.2f} %'
    df_result.loc['獲利因子',str(strategy_name)] = f'{win_factor:.2f}'
    df_result.loc['調整獲利因子',str(strategy_name)] = f'{adjust_win_factor:.2f}'
    df_result.loc['策略夏普比率',str(strategy_name)] = f'{sharp_ratio:.2f}'
    df_result.loc['年夏普比率',str(strategy_name)] = f'{sharp_ratio_year:.2f}'
    if type!='DayTrade':
        df_ben = df_profit.copy().replace(to_replace=0, method='ffill')
        ## Count Benchmark sharp ratio
        df_month_ben = pd.DataFrame(df_ben.groupby(pd.Grouper(freq='ME'))['C'].last())
        df_month['C'] = pd.DataFrame(df.groupby(pd.Grouper(freq='ME'))['C'].last())
        df_month_ben['Benchmark_Return'] = df_month_ben['C'].pct_change()
        df_month['Benchmark_Return'] = df_month['C'].pct_change()
        benchmark_sharp_ratio_full = ((df_month_ben['Benchmark_Return'].mean()-0.0025)/df_month_ben['Benchmark_Return'].std())
        benchmark_sharp_ratio_onlyonboard = ((df_month['Benchmark_Return'].mean()-0.0025)/df_month['Benchmark_Return'].std())

        ## Count Nearly cumulative return of benchmark and Strategy  
        df['benchmark_Return'] = df['C'].pct_change()
        df_ben['benchmark_Return'] = df_ben['C'].pct_change()
        df_near = df.loc[datetime.today()-timedelta(days=90):,:]
        df_near_ben = df_ben.loc[datetime.today()-timedelta(days=90):,:]
        df_near['benchmark_Cum_return'] = (df_near['benchmark_Return']+1).cumprod()-1
        df_near_ben['benchmark_Cum_return'] = (df_near_ben['benchmark_Return']+1).cumprod()-1
        df_near['Cum_return'] = (df_near['Return']+1).cumprod()-1
        near_benchmark_return_full = df_near_ben.iloc[-1]['benchmark_Cum_return']*100
        near_benchmark_return_onlyonboard = df_near.iloc[-1]['benchmark_Cum_return']*100
        near_return = df_near.iloc[-1]['Cum_return']*100
        df_result.loc['大盤夏普比率(FullTime)',str(strategy_name)] = f'{benchmark_sharp_ratio_full:.2f}'
        df_result.loc['大盤夏普比率(OnlyOnboard)',str(strategy_name)] = f'{benchmark_sharp_ratio_onlyonboard:.2f}'
        df_result.loc['大盤近3個月累積報酬率(FullTime)',str(strategy_name)] = f'{near_benchmark_return_full:.2f} %'
        df_result.loc['大盤近3個月累積報酬率(OnlyOnboard)',str(strategy_name)] = f'{near_benchmark_return_onlyonboard:.2f} %'
        df_result.loc['策略近3個月累積報酬率',str(strategy_name)] = f'{near_return:.2f} %'

    df_onboard = df.loc[activate_date:]
    df_onboard['Cum_return'] = (df_onboard['Return']+1).cumprod()-1
    onboard_return = df_onboard.iloc[-1]['Cum_return']*100
    df_result.loc['策略上線累積報酬率',str(strategy_name)] = f'{onboard_return:.2f} %'

    dfi.export(df_result,RETURN_PICTURE_DIR/f"{market_name}_Backtest.jpg")

def find_neighbours(value, df, colname):
    diffs = abs(df[colname] - value)
    closest_index = diffs.idxmin()
    return df.loc[closest_index, colname]

def write_to_excel(file_path, data, sheet_name):
    '''
    Function to write data to an Excel file.
    file_path : path of excel.
    data : df, data to write in excel.
    sheet_name : str, sheet name.

    '''
    with pd.ExcelWriter(file_path, mode="a", engine="openpyxl", if_sheet_exists="replace") as writer:
        data.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

def calculate_summary(history_profit, strategy_name,Date_col):
    """
    Function to calculate monthly, yearly, and total summaries.
    Date_col : columns which contain date (This step is to make sure the columns of date is datetime format.)
    """
    history_profit[Date_col] = pd.to_datetime(history_profit[Date_col])
    df_name = pd.DataFrame([['Name', strategy_name]], columns=[0, 1])
    df_month = history_profit.groupby(history_profit[0].dt.to_period("M"))[1].sum().reset_index()
    df_year = history_profit.groupby(history_profit[0].dt.to_period("Y"))[1].sum().reset_index()
    df_week = history_profit.groupby(history_profit[0].dt.to_period("W"))[1].sum().to_frame()
    diff_lastweek = df_week[1].sum(axis=0) - df_week.iloc[:-1][1].sum(axis=0)
    df_total = pd.concat([df_name, df_month, df_year], axis=0)
    df_total.loc['Diff from last week'] = diff_lastweek 
    return df_total

def count_market_dimention(goods_name):
    """
    Function to count the daily dimention of market
    goods_name: market name (ex: TXFDay,TXFNight,NQ,HTI...)
    """
    df_market = pd.read_csv(STRATEGIES_DIR / f"{goods_name}_daily.txt")
    df_market.columns = ['Date', 'Time', 'O', 'H', 'L', 'C']
    df_market = df_market.set_index('Date')
    df_market.index = pd.to_datetime(df_market.index)
    df_market['H-L'] = abs(df_market['H'] - df_market['L']) / df_market['O'] * 100
    df_market['C-O'] = (df_market['C'] - df_market['O']) / df_market['O'] * 100
    df_market['C-O/H-L'] = np.where(df_market['H-L']!=0,abs(df_market['C-O']/df_market['H-L']),0)
    df_market['H-L_Rank'] = df_market['H-L'].rank() / len(df_market)
    df_market['Count1'] = [df_x[df_x['X'] == find_neighbours(i, df_x, 'X')][6].values[0] for i in df_market['H-L_Rank']]
    df_market['Count2'] = [df_y[df_y['Y'] == find_neighbours(i, df_y, 'Y')][7].values[0] for i in df_market['C-O/H-L']]
    df_market['Count3'] = np.where(
        (df_market['Count1'] >= 6) & (df_market['H-L'] > 1.8),
        np.where(df_market['Count2'] >= 7, 4, 1),
        np.where(df_market['Count2'] >= 7, 3, 2))
    return df_market

def read_market_data(goods_name):
    """
    Function to read the market data only (Since Swing Strategy didn't need to count dimention but still need market data).
    goods_name: market name (ex: TXFDay,TXFNight,NQ,HTI...)
    """
    df_market = pd.read_csv(STRATEGIES_DIR / f"{goods_name}_daily.txt")
    df_market.columns = ['Date', 'Time', 'O', 'H', 'L', 'C']
    df_market = df_market.set_index('Date')
    df_market.index = pd.to_datetime(df_market.index)
    return df_market

def set_dimention_to_legend(data,dim_color_map):
    '''
    Function to make the dimention mark as legend on the picture.
    (Input)
    data : df, market data with dimention (daily dimention columns name: Count3)
    dim_color_map : dict, color for each dimention
    (Output)
    icon color : green represent expectation of that dimention is greater than 0, else red.
    numeric : expectation of that dimention (if greater than 1 then will mark as blue.) 
    '''
    legend_patches = []
    legend_txtcolor = []
    for i in dim_color_map:
        # frequency of each dimnention in backtest.
        # dim_frq = round(len(data[data['Count3']==i])/len(data)*100,2)
        dim_win = len(data[(data['Count3']==i)&(data[1]>0)])/max(1,len(data[(data['Count3']==i)]))
        dim_rat = (data[(data['Count3']==i)&(data[1]>0)])[1].mean()/max(1,-(data[(data['Count3']==i)&(data[1]<0)])[1].mean())
        dim_exp = dim_rat*dim_win-(1-dim_win)
        iconcolor = 'green' if dim_exp > 0 else 'red'
        txtcolor = 'royalblue' if dim_exp>1 else 'black'
        legend_patches.append(mpatches.Patch(color=iconcolor, label=f'{i} :  '+str(round(dim_exp,2))))
        legend_txtcolor.append(txtcolor)
    total_win = len(data[data[1]>0])/len(data)
    total_rat = (data[data[1]>0])[1].mean()/max(1,-(data[data[1]<0])[1].mean())
    total_exp = total_rat*total_win-(1-total_win)
    total_iconcolor = 'green' if total_exp > 0 else 'red'
    total_txtcolor = 'royalblue' if total_exp > 1 else 'black'
    legend_patches.append(mpatches.Patch(color=total_iconcolor, label=f'Total : '+str(round(total_exp,2))))
    legend_txtcolor.append(total_txtcolor)

    plt.legend(handles=legend_patches, title="象限期望值", loc='upper left',labelcolor=legend_txtcolor)
    # if you want to plot the dimentiona as background then unmarked below row.
    # plt.bar(history_profit[0],history_profit[1].cumsum().max(), color=[dim_color_map[i] for i in data['Count3']],alpha=0.3,width=1)

def plot_return(history_profit,strategy_name,Date_col,profit_col):
    '''
    Funtion to plot return for each strategy.
    history_profit : df, data which record date and historical daily profit.
    strategy_name : str, strategy name.
 
    '''
    plt.plot(history_profit[Date_col],history_profit[profit_col].cumsum(),label=strategy_name)
    plt.scatter(history_profit[history_profit[1].cumsum()==history_profit[profit_col].cumsum().max()].iloc[-1][Date_col],history_profit[profit_col].cumsum().max(),s=20,color='darkblue')
    plt.text(history_profit[history_profit[1].cumsum()==history_profit[profit_col].cumsum().max()].iloc[-1][Date_col],history_profit[profit_col].cumsum().max()+1000,str(history_profit[history_profit[1].cumsum()==history_profit[profit_col].cumsum().max()].iloc[-1][Date_col])[5:10],color='black')
    plt.title(strategy_name,fontsize=24)
    mdd,mdd_pct = count_mdd(history_profit[profit_col].cumsum(),len(history_profit))
    week_max_mdd_pct = round(min(mdd_pct.values[-5:]),2)
    if week_max_mdd_pct<=-50:
        plt.title(strategy_name+f' (Mdd Exit 50% : {week_max_mdd_pct} %)',fontsize=20, color='Red')
    else:
        plt.title(strategy_name,fontsize=20)
    
    plt.fill_between(history_profit[Date_col],mdd,color='C01')
    # if you want to plot cumulative profit as a certain frequency then unmarked below two rows and enter the frequency to f.
    # f = "MS"
    # plt.xticks(pd.date_range(start=history_profit[Date_col][0], end=history_profit[Date_col][len(history_profit)-1],freq=f),[i[2:] for i in pd.date_range(start=history_profit[Date_col][0], end=history_profit[Date_col][len(history_profit)-1], freq=f).strftime('%Y%m')])
    plt.grid(True,linestyle='--')

def check_require_folder(folder_name):
    try:
        if not os.path.exists(folder_name):
            os.makedirs(folder_name)
            print(f"{folder_name} created successfully.")
    except PermissionError:
        print(f"Permission denied to create {folder_name}")

def Record(Strategies,Active_Dates,goods_name,type='DayTrade'):
    dim_color_map = {1: 'darkorange',2: 'red',3: 'royalblue',4: 'green'}
    last_record_date = datetime.strftime(datetime.today(),"%Y-%m-%d %H:%M:%S")
    df_result = pd.DataFrame()
    ## Set total plot
    if len(Strategies)<4:
        plt.figure(figsize=(10*len(Strategies),2+5))
    else:
        plt.figure(figsize=(10*4,2+5*int(np.ceil(len(Strategies)/4))))

    for s in Strategies:
        active_date = Active_Dates[Strategies.index(s)]
        logging.info(f"Processing : {s}")
        total_num = len(Strategies)
        num = Strategies.index(s)+1

        ## Read lastest profit 
        today_profit, date ,lastday_profit, lastdate = read_lastest_profit(s)

        ## Read history data and Update
        history_profit = read_history_profit(s)
        history_profit = update_history_profit(history_profit, today_profit, date, lastday_profit, lastdate, 0)

        ## Set Total plot title
        if s==Strategies[0]:
            start_date = history_profit.index[0].replace(month=1,day=1)
            plt.suptitle(f'Period : {start_date} ~ {last_record_date}',size=25)
            plt.subplots_adjust(top=0.88,wspace=0.1, hspace=0.2)
       
        ## Count market dimention & Backtest
        if type=='DayTrade':
            df_market = count_market_dimention(goods_name)
            df_mix = pd.concat([history_profit,df_market[['Count3']]],axis=1,join='inner')
            count_backtest(df_mix,df_result,s,goods_name,active_date)
        else:
            df_market = read_market_data(goods_name)
            df_mix = pd.concat([history_profit,df_market[['C']]/1000],axis=1,join='inner')
            df_mix_outer = pd.concat([history_profit,df_market[['C']]/1000],axis=1,join='outer')
            count_backtest(df_mix_outer,df_result,s,goods_name,active_date,type='Swing')

        history_profit = history_profit.reset_index()
        ## Plot subplot
        if total_num<4:
            plt.subplot(1,len(Strategies),num)
        else:
            plt.subplot(int(np.ceil(total_num/4)),4,num)
        if type=='DayTrade':
            plt.axvline(pd.to_datetime(active_date),color='C03',linestyle='--',label='Active Date : '+active_date)
            set_dimention_to_legend(df_mix,dim_color_map)
        
        if type!='DayTrade':
            plt.plot(df_mix.index,df_mix['C'],linewidth=1,alpha=0.5,color='C02',label=goods_name+" (10^3)")
            plt.axvline(pd.to_datetime(active_date),color='C03',linestyle='--',label='Active Date : '+active_date)
            plt.legend(loc='upper left')
            plt.grid(axis='x')
            plt.twinx()
        plot_return(history_profit,s,Date_col=0,profit_col=1)
        
        
        
        ## Update to excel
        write_to_excel(BASE_DIR / "Historical Strategy Model Profit.xlsx",history_profit,s)
        write_to_excel(BASE_DIR / "Strategy_profit.xlsx",calculate_summary(history_profit,s,0),s)
        # write_to_excel(OTHER_DIR / "Strategy_profit.xlsx",calculate_summary(history_profit,s,0),s)
        try:
            logging.info(f"Successfully processed {s}.")
        except Exception as e:
            logging.error(f"Error processing {s}: {e}")

    plt.savefig(RETURN_PICTURE_DIR / f"{goods_name}_{type}.jpg")


if __name__ == '__main__':
    check_require_folder(LOG_DIR)
    check_require_folder(STRATEGIES_DIR)
    check_require_folder(RETURN_PICTURE_DIR)

    logging.basicConfig(
    filename=LOG_DIR / f"daily_model_profit_{datetime.now():%Y-%m-%d}.log",
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s')

    logging.info("=============================(Start)==================================")

    for key,item in goods.items():
        activeStrategy = [key_s for key_s, value_s in item.items() if value_s[0]==True]
        activeDate = [value_s[1] for key_s, value_s in item.items() if value_s[0]==True]
        print(key,' : ',activeStrategy)
        if len(activeStrategy)==0:
            pass
        else:
            try:
                key = key.split("_")
                if "SWING" in key:
                    Record(activeStrategy,activeDate,goods_name=key[0],type="Swing")
                else:
                    Record(activeStrategy,activeDate,goods_name=key[0],type="DayTrade")
            except Exception as e:
                logging.error(f"Error processing {key}: {e}", exc_info=True)

    logging.info("==============================(End)=================================")